 class Cella {
		
		Object elemento;
		
		Puntatore successivo=null; 

		public Cella(Object e){
			elemento = e;
		}

	}
		