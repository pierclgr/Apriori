

class Puntatore  {
	
		public Cella link;
		
		public Puntatore(Cella c) {
			link = c;
		}
	}